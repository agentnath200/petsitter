# Posts
A post sytem for my friend Shidan
Js for client
